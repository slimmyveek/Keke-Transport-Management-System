<?php
require 'includes/connect.php';
include('includes/header.php');
include('includes/sidebar.php');
?>

<!-- Main content -->
        <div class="container">
            <div class="p-3">
            <h3>
            <?php
            $email = $_SESSION['fullname'];
            $query= "SELECT * FROM user where email='$email' ";
            $result = mysqli_query ($con, $query);
            if ($fetch = $result->fetch_assoc()){
                echo "Hi, " . $fetch['fullname'] . ".";
            }
            ?>
            </h3>
            </div>

            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-header">
                            <h5 class="m-2 text-light">Quick Tips</h5>
                        </div>
                        <div class="card-body">
                            <ol>
                                <li>
                                    Use the links at the left to navigate easily.
                                </li>

                                <li>
                                    You can see list of schedules by clicking on <strong>New Booking</strong>. The
                                    system will display a list of available schedules for you which you can view
                                    and make bookings from.
                                </li>

                                <li>
                                    You are allowed to view all your booking history by clicking on <strong>View
                                        Bookings</strong>.
                                </li>

                                <li>
                                    And, if at any point in your trip, you are dissatisfied with your journey with
                                    us, you can send us a feedback to help us serve you better.
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>