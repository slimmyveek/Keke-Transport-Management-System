<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
    <h4>Change Password</h4>

    <?php
    if (isset($_POST["submit"])) {
        $email = $_SESSION['fullname'];
        $oldPassword = $_POST["oldPassword"];
        $newPassword = $_POST["newPassword"];
        $confirmPassword = $_POST["confirmPassword"];

        if ($newPassword === $confirmPassword) {

            $query = "UPDATE user SET password = '$newPassword', cpassword = '$confirmPassword' WHERE email='$email' ";
            $result = mysqli_query($con, $query);

            if ($result === true) {
                echo "<div class='alert alert-success' role='alert'> Your password has been changed successfully. </div>";
            } else {
                echo "<div class='alert alert-danger' role='alert'> Sorry, you can't change your password at this time. </div>";
            }
        } else if ($newPassword != $confirmPassword) {
            echo "<div class='alert alert-danger' role='alert'> The passwords you have provided do not match. Kindly check and try again. </div>";
        }
    }
    ?>

    <form method="POST">
        <p>Old Password: <input type="password" class="form-control" name="oldPassword" required id=""></p>

        <p> New Password: <input type="password" class="form-control" name="newPassword" required id=""></p>

        <p> Confirm New Password: <input type="password" class="form-control" name="confirmPassword" required id=""></p>

        <input class="btn btn-warning" type="submit" value="Change Password" name='submit' style="width:30%">
    </form>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>