<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class='alert alert-primary' role='alert'>
                    <h5><i class="fas fa-info"></i> Info:</h5>
                    Trip History and Print Bookings
                </div>

                <div class="card">
                    <div class="card-header alert-success">
                        <h5 class="m-2 text-light">Booking History</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered" id='example1'>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Route</th>
                                    <th>Tricycle No.</th>
                                    <th>Trip Date / Time</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM booked WHERE passenger_id = '" . $_SESSION['fullname'] . "' ORDER BY booking_id DESC";
                                $result = mysqli_query($con, $query);

                                if ($result->num_rows < 1)
                                    echo "<div class='alert alert-danger' role='alert'> You don't have any trip record with us yet. Try booking a ride. </div>";;

                                $sn = 0;

                                // Fetching the route fullname from the database
                                while ($row = $result->fetch_assoc()) {
                                    $cond = $con->query("SELECT * FROM route WHERE route_id = '" . $row['route'] . "'");
                                    while ($r = $cond->fetch_assoc()) {

                                        $curr_date = strtotime(date("d-m-Y"));
                                        $db_date = strtotime($row['date']);
                                        $db_time = strtotime($row['time']);
                                        $curr_time = strtotime(date('H:i'));

                                        $id = $row['booking_id'];
                                        $sn++;
                                        echo "<tr>
                                    <td>$sn</td>
                                    <td>" . ($r['start']) . " to " . ($r['stop']) . "</td>
                                    <td>" . $row['plate_no'] . "</td>
                                    <td>" . $row['date'], " / ", $row['time'] . "</td>
                                    <td>" . ($db_date >= $curr_date && $db_time >= $curr_time ? '<span class="text-bold text-success">Active' : '<span class="text-bold text-danger">Expired') . "</span></td>
                                    <td>
                                    <button type='button' class='btn btn-primary'>
                                    Print
                                </button>
                                    </td>
                                      
                                    </tr>";
                                    }
                                ?>

                                <?php
                                }
                                ?>
                            </tbody>
                        </table>


                    </div>

                    <br />
                </div>
            </div>
        </div>
    </div>
</section>


<?php
include('includes/scripts.php');
include('includes/footer.php');
?>