<?php
session_start();
require 'includes/connect.php';
?>

<!--Side Bar-->
<div class="sidebar bg-dark">
    <div class="brand pt-3">
        <img src="img/steering.png" alt="" style="width: 13%; margin-right: 10px;">
        <h5>Keke Transport Management System </h5>
    </div>

    <!-- Current Date -->
    <div class="sidemenu date text-light text-center">
        <?php
        date_default_timezone_set('Africa/Lagos');
        $current_date = date('l, j F, Y');
        echo $current_date;
        ?>
        <br>

        <!-- Current Time -->
        <?php
        date_default_timezone_set('Africa/Lagos');
        $current_time = date('G:i:s');
        echo $current_time;
        ?>
    </div>

    <!--Side Menu-->
    <div class="sidemenu">
        <div class="side-user">
            <div class="side-img" style="background-image: url(<?php $email = $_SESSION['fullname'];
                                                                $query = "SELECT * FROM user where email='$email' ";
                                                                $result = mysqli_query($con, $query);
                                                                if ($fetch = $result->fetch_assoc()) {
                                                                    echo "img/" . ($fetch['upload']);
                                                                }
                                                                ?>"></div>
            <div class="user">
                <small style="color: #e0b800;"> <?php
                                                $email = $_SESSION['fullname'];
                                                $query = "SELECT * FROM user where email='$email' ";
                                                $result = mysqli_query($con, $query);
                                                if ($fetch = $result->fetch_assoc()) {
                                                    echo $fetch['fullname'];
                                                }
                                                ?></small>
            </div>
        </div>

        <nav class="mt-2">
            <ul id="nav" class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="passenger_dashboard.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-home mx-3"></i>
                        Dashboard
                    </a>
                </li>

                <li class="nav-item">
                    <a href="new_booking.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-plus mx-3"></i>
                        New Booking
                    </a>
                </li>

                <li class="nav-item">
                    <a href="view_bookings.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-book mx-3"></i>
                        View Bookings
                    </a>
                </li>

                <li class="nav-item">
                    <a href="feedback.php" class="nav-link mx-3">
                        <i class="nav-icon fa fa-mail-bulk mx-3"></i>
                        Feedback
                    </a>
                </li>

                <li class="nav-item">
                    <a href="change_password.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-lock mx-3"></i>
                        Change Password
                    </a>
                </li>

                <li class="nav-item">
                    <a href="logout.php" class="nav-link mx-3" onclick="return confirm('Are you sure you want to log out?')">
                        <i class="nav-icon fas fa-power-off mx-3"></i>
                        Log out
                    </a>
                </li>
            </ul>
    </div>
</div>
<!-- <script>
    // Get the container element
    var liContainer = document.getElementById("nav");

    // Get all buttons with class="btn" inside the container
    var a = liContainer.getElementsByClassName("nav-link");

    // Loop through the buttons and add the active class to the current/clicked button
    for (var i = 0; i < a.length; i++) {
        a[i].addEventListener("click", function() {
            var current = document.getElementsByClassName("active");

            if (current.length > 0) {
                current[0].className = current[0].className.replace(" active", "");
            }

            this.className += " active";
        });
    }
</script> -->