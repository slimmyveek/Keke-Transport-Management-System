 <!-- Footer -->
 <footer>
            <div class="p-5 text-center">
                <small> Copyright &copy; 2023 All Rights Reserved. </small>
            </div>
        </footer>
    </div>

</body>

</html>