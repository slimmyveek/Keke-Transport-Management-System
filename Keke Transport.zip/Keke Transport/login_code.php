<?php
session_start();
include('includes/connect.php');

if (isset($_POST["submit"])){
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    $query= "SELECT * FROM user where email='$email' AND password='$password'";
    $result = mysqli_query ($con, $query);
    
    if (mysqli_fetch_array($result)){
        $_SESSION ['fullname'] = $email;
        header ('Location: passenger_dashboard.php');
    } else {
        $_SESSION ['status'] = 'Your email or password is incorrect.';
        header ('Location: passenger_login.php');
    }
}

?>