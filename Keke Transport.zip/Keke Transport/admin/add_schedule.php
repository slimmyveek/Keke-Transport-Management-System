<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
    <h4>Add New Schedule</h4>

    <?php


    if (isset($_POST["submit"])) {
        $tricycle_id = $_POST["tricycle_id"];
        $route_id = $_POST["route_id"];
        $seat = $_POST["seat"];
        // $date = date(($_POST["date"]));
        $the_date = explode('-', $_POST["date"]);
        $date = $the_date['2'] . '-' . $the_date['1'] . '-' . $the_date['0'];
        $time = date($_POST["time"]);
        $fare = $_POST["fare"];

        $query = "INSERT INTO schedule (tricycle_id, route_id, seat, date, time, fare) VALUES ('$tricycle_id', '$route_id', '$seat', '$date', '$time', '$fare')";
        $result = mysqli_query($con, $query);

        if ($result === true) {
            //  header('Location: schedules.php');
            echo "<div class='alert alert-success' role='alert'> New schedule added successfully. </div>";
        } else {
            // header('Location: schedules.php');
            echo "<div class='alert alert-danger' role='alert'> Sorry, this schedule can not be added at this time. </div>";
        }
    }
    ?>
    <form action="" method="post">
        <div class="row pb-3">
            <div class="col-sm-6">
                Tricycle Details: <select class="form-control" name="tricycle_id" required id="">
                    <option value="">---Select Tricycle---</option>
                    <?php
                    $r = $con->query("SELECT * FROM tricycle");
                    while ($row = $r->fetch_assoc()) {
                        echo "<option value='" . $row['tricycle_id'] . "'>" . $row['plate_no'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-sm-6">
                Route: <select class="form-control" name="route_id" required id="">
                    <option value="">---Select Route---</option>
                    <?php
                    $r = $con->query("SELECT * FROM route");
                    while ($row = $r->fetch_assoc()) {
                        echo "<option value='" . $row['route_id'] . "'>" . $row['start'] . ' to ' . ($row['stop']) . "</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <div class="row pb-3">
            <div class="col-sm-6">
                Fare <small><em>(in Naira)</em></small>: <input class="form-control" type="number" name="fare" value='300' required id="">
            </div>
            <div class="col-sm-6">
                Total Available Seats: <input class="form-control" type="number" name="seat" value='5' required id="">
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                Date: <input class="form-control" onchange="check(this.value)" type="date" name="date" required id="">
            </div>
            <div class="col-sm-6">
                Time: <input class="form-control" type="time" name="time" required id="">
            </div>
        </div>

        <hr>
        <input type="submit" name="submit" class="btn btn-warning" value="Add Schedule" style="width:30%;">
    </form>

    <a href="schedules.php" class=""><button type="button" class="btn btn-dark mt-2" style="border-radius:20px; width: 30%;">Back</button></a>

    <!-- <script>
        function check(val) {
            val = new Date(val);
            var age = (Date.now() - val) / 31557600000;
            var formDate = document.getElementById('date');
            if (age > 0) {
                alert("Past/Current Date not allowed!");
                formDate.value = "";
                return false;
            }
        }
    </script> -->

    <?php
    include('includes/scripts.php');
    include('includes/footer.php');
    ?>