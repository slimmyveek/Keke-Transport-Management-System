<?php
require 'includes/connect.php';
include('includes/header.php');
include('includes/sidebar.php');
?>

        <main>
            <div class="cards">
                <a href="users.php" class="href"><div class="card-single btn btn-warning">
                    <div>
                        <h1><i class="fa fa-users"></i></h1>
                    </div>
                    <div>
                        <h2><?php
                        echo $row =  $con->query("SELECT * FROM user")->num_rows;
                            ?></h2>
                        <small>Registered Users</small>
                    </div>
                </div>
                </a>

                <a href="tricycles_riders.php" class="href"><div class="card-single btn btn-warning">
                    <div>
                        <h1><i><img src="../img/tricycle_illustration_b.png" alt="" class="w-75"></i></h1>
                    </div>
                    <div>
                        <h2><?php
                        echo $row =  $con->query("SELECT * FROM tricycle")->num_rows;
                            ?></h2>
                        <small>Tricycles/Riders</small>
                    </div>
                </div>
                </a>

                <a href="schedules.php" class="href"><div class="card-single btn btn-warning">
                    <div>
                        <h1><i class="far fa-calendar-alt"></i></h1>
                    </div>
                    <div>
                        <h2><?php
                        echo $row =  $con->query("SELECT * FROM schedule")->num_rows;
                            ?></h2>
                        <small>Schedules</small>
                    </div>
                </div>
                </a>

                <a href="feedbacks.php" class="href"><div class="card-single btn btn-warning">
                    <div>
                        <h1><i class="fa fa-comment-dots"></i></h1>
                    </div>
                    <div>
                        <h2><?php
                        echo $row =  $con->query("SELECT * FROM feedback")->num_rows;
                            ?></h2>
                        <small>Feedbacks</small>
                    </div>
                </div>
                </a>
            </div>
        </main>
        
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>