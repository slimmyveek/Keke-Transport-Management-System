<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
    <h4>Edit Tricycle Details</h4>

    <?php
    $id = $_GET['edit_id'];
    if (isset($_POST["submit"])) {
        $plate_no = $_POST["tricycle"];
        $rider_name = $_POST["rider"];
        $route = $_POST["route_id"];
        $capacity = $_POST["capacity"];

        //checking if tricycle details already exist
        $check = $con->query("SELECT * FROM tricycle WHERE plate_no = '$plate_no' ")->num_rows;
        if ($check > 1) {
            echo "<div class='alert alert-danger' role='alert'> This tricycle detail already exists. </div>";
        } else {
            //proceeding to update with new details
            $edit_query = "UPDATE tricycle SET tricycle_id = $id, plate_no = '$plate_no', rider_name = '$rider_name', route = '$route', capacity = '$capacity' WHERE tricycle_id = $id";
            $res = mysqli_query($con, $edit_query);

            if ($res === true) {
                //  header('Location: tricycles_riders.php');
                echo "<div class='alert alert-success' role='alert'> Tricycle details modified successfully. </div>";
            } else {
                //  header('Location: edit_tricycle.php');
                echo "<div class='alert alert-danger' role='alert'> Sorry, this tricycle details could not be modified at this time. </div>";
            }
        }
    }
    ?>

    <form method="post">

        <?php
        $id = $_GET['edit_id'];
        $query = "SELECT * FROM tricycle where tricycle_id = '$id'";
        $row = mysqli_query($con, $query);
        $fetch = $row->fetch_assoc();
        ?>

        <!-- <input type="hidden" class="form-control" name="id" value="<?php echo $fetch['tricycle_id'] ?>" required id=""> -->

        <p>Tricycle Plate No: <input type="text" class="form-control" name="tricycle" value="<?php echo $fetch['plate_no'] ?>" required minlength="8" id=""></p>

        <p>
            Rider's Name: <input type="text" class="form-control" value="<?php echo $fetch['rider_name'] ?>" name="rider" required id="">
        </p>

        <p>
            Route: <select class="form-control" name="route_id" required id="">
                <option value="">--<?php echo $fetch['route'] ?>--</option>
                <?php
                $sql = "SELECT * FROM route";
                $result = mysqli_query($con, $sql);
                while ($retrieve = $result->fetch_assoc()) {
                    echo "<option value='" . $retrieve['start'] . " to " . $retrieve['stop'] . "'>" . $retrieve['start'] . ' to ' . $retrieve['stop'] . "</option>";
                }
                ?>
            </select>
        </p>

        <p>Maximum Capacity: <input type="number" min='1' class="form-control" value="<?php echo $fetch['capacity'] ?>" name="capacity" required id=""></p>

        <input class="btn btn-warning" type="submit" value="Edit Tricycle Details" name='submit' style="width:30%;">

    </form>
    <a href="tricycles_riders.php" class=""><button type="button" class="btn btn-dark mt-2" style="border-radius:20px; width: 30%;">Back</button></a>

</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>