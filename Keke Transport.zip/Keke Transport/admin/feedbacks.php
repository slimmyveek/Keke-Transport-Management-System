<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card card-warning">
                <div class="card-header">
                    <h5 class="card-title m-2 text-light">
                        All Feedbacks</h5>
                </div>

                <div class="card-body">

                    <table id="example1" style="align-items: stretch;" class="table table-hover w-100 table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Passenger</th>
                                <th>Message</th>
                                <th>Reply</th>
                                <th style="width: 10%; text-align: center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM feedback order by feedback_id DESC";
                            $row = mysqli_query($con, $query);
                            if ($row->num_rows < 1) echo "<div class='alert alert-danger' role='alert'> There are no feedbacks yet. </div>";
                            $sn = 0;
                            while ($fetch = $row->fetch_assoc()) {
                                $id = $fetch['feedback_id'];
                            ?>

                                <tr>
                                    <td><?php echo ++$sn; ?></td>
                                    <td><?php echo $fullname = $fetch['passenger_id']; ?></td>
                                    <td>
                                        <em><?php echo $fetch['message']; ?></em>
                                        <br>
                                        <em><small class="text-secondary">~ Received: <?php echo $fetch['date']; ?></small></em>
                                    </td>
                                    <td class="text-primary"><?php echo $response = $fetch['response']; ?></td>
                                    <td style='text-align: center;'>
                                        <form method="POST">
                                            <?php
                                            if ($response == NULL) {
                                            ?>
                                                <a href="reply_feedback.php?passenger_id=<?php echo $fetch['passenger_id']; ?>" class="href"><button type="button" class="btn btn-primary">
                                                        Reply
                                                    </button></a>
                                            <?php
                                            } else {
                                                echo "<button disabled='disabled' class='btn btn-secondary'>Replied</button>";
                                            }
                                            ?>


                                        </form>
                                    </td>
                                </tr>


                            <?php
                            }
                            ?>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>