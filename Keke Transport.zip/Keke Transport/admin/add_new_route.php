<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
<h4>Add new route</h4>

<?php
 if (isset($_POST["submit"])){
     $start = $_POST["start"];
     $stop = $_POST["stop"];
     
     $query = "INSERT INTO route (start, stop) VALUES ('$start', '$stop')";
     $result = mysqli_query ($con, $query);

 if ($result){
    //  header('Location: routes.php');
    echo "<div class='alert alert-success' role='alert'> Route added successfully. </div>";
 } 
 else {
     header('Location: add_new_route.php');
     echo "<div class='alert alert-danger' role='alert'> Sorry, this route can not be added at this time. </div>";
 }
}
?>

<form method = "POST">
        <p>From: <input type="text" class="form-control" name="start" required id=""></p>
        
        <p> To: <input type="text" class="form-control" name="stop" required id=""></p>
        
        <input class="btn btn-warning" type="submit" value="Add Route" name='submit' style="width:30%">
</form>
        <a href="routes.php" class=""><button class="btn btn-dark mt-2" style="border-radius:20px; width: 30%;">Back</button></a>

</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>