<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card card-success">
                <div class="card-header d-flex" style="justify-content: space-between;">
                    <h5 class="card-title m-2 text-light">
                        All Schedules</h5>
                    <div class="mt-1">
                        <a href="add_schedule.php"><button type="button" class="btn btn-dark btn-sm">
                                Add New One-Time Schedule &#128393;
                            </button></a>
                        <a href="range_schedule.php"><button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#add2">
                                Add Range Schedule &#128356;
                            </button></a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- <?php
                            $d = $con->query("SELECT * FROM schedule");
                            $fetch = $d->fetch_assoc();
                            $id = $fetch['schedule_id'];
                            if (isset($_POST['edit'])) {
                                $query = "UPDATE schedule SET tricycle WHERE schedule_id = $id";
                                $r = mysqli_query($con, $query);
                                if ($r === true) {
                                    echo "<div class='alert alert-success' role='alert'> Schedule deleted successfully. </div>";
                                } else {
                                    echo "<div class='alert alert-danger' role='alert'> Sorry, you can't erase this schedule at this time. </div>";
                                }
                            }
                            ?> -->

                    <?php
                    $d = $con->query("SELECT * FROM schedule");
                    $fetch = $d->fetch_assoc();
                    // $id = $fetch['schedule_id'];
                    if (isset($_POST['delete'])) {
                        $query = "DELETE FROM schedule WHERE schedule_id = $id";
                        $r = mysqli_query($con, $query);
                        if ($r === true) {
                            echo "<div class='alert alert-success' role='alert'> Schedule deleted successfully. </div>";
                        } else {
                            echo "<div class='alert alert-danger' role='alert'> Sorry, you can't erase this schedule at this time. </div>";
                        }
                    }
                    ?>

                    <!--Creating "Paid" and "Not Paid" buttons to signify Ticket Status -->
                    <?php
                    if (isset($_POST['not_paid'])) {
                        $id = $_POST['id'];
                        $t = $con->query("UPDATE schedule SET ticket_status = 1 WHERE schedule_id = '" . $id . "'");
                    }
                    ?>

                    <?php
                    if (isset($_POST['paid'])) {
                        $id = $_POST['id'];
                        $t = $con->query("UPDATE schedule SET ticket_status = 0 WHERE schedule_id = '" . $id . "'");
                    }
                    ?>

                    <table id="example1" style="align-items: stretch;" class="table table-hover w-100 table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tricycle No.</th>
                                <th>Route</th>
                                <th>Fare</th>
                                <th>Total Seats</th>
                                <th>Date/Time</th>
                                <th style="width: 8%; text-align: center;">Delete</th>
                                <th style='width: 13%; text-align: center;'>Ticket Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM schedule WHERE date = '" . date("d-m-Y") . "' ORDER BY date ASC, time ASC";
                            $row = mysqli_query($con, $query);

                            if ($row->num_rows < 1)
                                echo "<div class='alert alert-danger' role='alert'> There are currently no schedules available at this time! </div>";
                            $sn = 0;
                            while ($fetch = $row->fetch_assoc()) {
                                //Check if the current date is same with Database scheduled date
                                $curr_date = strtotime(date("d-m-Y"));
                                $db_date = strtotime($fetch['date']);
                                if ($db_date == $curr_date) {
                                    //Oh yes, so what should happen?
                                    //Check for the time. If there is still about an hour left, proceed else, skip this data
                                    $db_time = strtotime($fetch['time']);
                                    $curr_time = strtotime(date('H:i'));
                                    if ($curr_time >= $db_time) {
                                        continue;
                                    }
                                }
                                $id = $fetch['schedule_id']; ?><tr>
                                    <td><?php echo ++$sn; ?></td>
                                    <td><?php
                                        $cond = $con->query("SELECT * FROM tricycle WHERE tricycle_id = '" . $fetch['tricycle_id'] . "'");
                                        while ($r = $cond->fetch_assoc()) {
                                            echo ($r['plate_no']);
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $cond = $con->query("SELECT * FROM route WHERE route_id = '" . $fetch['route_id'] . "'");
                                        while ($r = $cond->fetch_assoc()) {
                                            echo ($r['start']) . " to " . ($r['stop']);
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo ($fetch['fare']) . " <small>Naira</small>"; ?></td>
                                    <td><?php echo ($fetch['seat']) . " seat(s)"; ?></td>
                                    <td><?php echo $fetch['date'], " / ", $fetch['time']; ?></td>

                                    <td class='text-center'>
                                        <form method="POST">
                                            <input type="hidden" class="form-control" name="id" value="<?php echo $id ?>" required id="">
                                            <!-- <button type="button" name="edit" class="btn btn-primary">
                                                <i class="nav-icon fas fa-edit"></i>
                                            </button> - -->

                                            <button type="submit" onclick="return confirm('Are you sure you want to delete this schedule?')" name="delete" class="btn btn-danger">
                                                <i class="nav-icon fas fa-trash"></i>
                                            </button>

                                    </td>

                                    <td style='text-align: center;'>
                                        <?php
                                        $t = $con->query("SELECT * FROM schedule");
                                        $ticket_status = $fetch['ticket_status'];
                                        if ($ticket_status == 0) {
                                        ?>
                                            <button type="not_paid" name="not_paid" class="btn btn-danger" onclick="return confirm('You are about to confirm that the rider of this tricycle has paid for today\'s ticket. Confirm?')">Not Paid <i class="nav-icon fas fa-times-circle"></i></button>
                                        <?php } else { ?>
                                            <button type="paid" name="paid" class="btn btn-success">Paid <i class="nav-icon fas fa-check-circle"></i></button>
                                        <?php } ?>
                                        </form>
                                    </td>

                                </tr>

                            <?php
                            }
                            ?>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php
    include('includes/scripts.php');
    include('includes/footer.php');
    ?>