<script src="../jquery/jquery.slim.min.js"></script>
<script src="../jquery/js/popper.min.js"></script>
<script src="../bootstrap-5.2.2-dist/js/bootstrap.min.js"></script>