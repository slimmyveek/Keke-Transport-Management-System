<?php
session_start();
require 'includes/connect.php';
?>

<!--Side Bar-->
<div class="sidebar bg-dark">
    <div class="brand pt-3">
        <img src="../img/steering.png" alt="" style="width: 13%; margin-right: 10px;">
        <h5>Keke Transport Management System </h5>
    </div>

    <!-- Current Date -->
    <div class="sidemenu date text-light text-center">
        <?php
        date_default_timezone_set('Africa/Lagos');
        $current_date = date('l, j F, Y');
        echo $current_date;
        ?>
        <br>

        <!-- Current Time -->
        <?php
        date_default_timezone_set('Africa/Lagos');
        $current_time = date('G:i:s');
        echo $current_time;
        ?>
    </div>

    <!--Side Menu-->
    <div class="sidemenu">
        <div class="side-user">
            <div class="side-img" style="background-image: url(../img/admin_avatar.png)"></div>
            <div class="user">
                <small style="color: #e0b800;">Administrator</small>
            </div>
        </div>

        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="admin_dashboard.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-home mx-3"></i>
                        Dashboard
                    </a>
                </li>

                <li class="nav-item">
                    <a href="users.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-users mx-3"></i>
                        Users
                    </a>
                </li>

                <li class="nav-item">
                    <a href="schedules.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-calendar-alt mx-3"></i>
                        Schedules
                    </a>
                </li>

                <li class="nav-item">
                    <a href="routes.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-route mx-3"></i>
                        Routes
                    </a>
                </li>

                <li class="nav-item">
                    <a href="tricycles_riders.php" class="nav-link mx-4">
                        <img src="../img/tricycle_illustration.png" class="mx-2" alt="" style="width: 11%;">
                        <!-- &#128643 -->
                        Tricycles/Riders
                    </a>
                </li>

                <li class="nav-item">
                    <a href="feedbacks.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-mail-bulk mx-3"></i>
                        Feedbacks
                    </a>
                </li>
                <li class="nav-item">
                    <a href="admin_change_password.php" class="nav-link mx-3">
                        <i class="nav-icon fas fa-lock mx-3"></i>
                        Change Password
                    </a>
                </li>

                <li class="nav-item">
                    <a href="logout.php" class="nav-link mx-3" onclick="return confirm('Are you sure you want to log out?')">
                        <i class="nav-icon fas fa-power-off mx-3"></i>
                        Log out
                    </a>
                </li>
            </ul>
    </div>
</div>