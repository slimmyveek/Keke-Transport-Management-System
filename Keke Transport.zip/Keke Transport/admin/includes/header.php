<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../bootstrap-5.2.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-5.15.4-web/css/all.min.css">
    <link rel="stylesheet" href="../style.css">
    <title>Admin's Dashboard</title>
</head>

<body>


    <div class="main-content">
        <header>
            <label for="" class="menu-toggle">
                <i class="nav-icon fas fa-bars"></i>
            </label>
            <div class="search">
                <i class="fas fa-search"></i>
                <input type="search" placeholder="Search here...">
            </div>
            <div>
                <i class="fas fa-bell"></i>
                <i class="fas fa-bookmark"></i>
                <i class="fas fa-comment"></i>
            </div>
        </header>