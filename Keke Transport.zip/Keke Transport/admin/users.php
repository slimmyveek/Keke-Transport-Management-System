<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>


<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card card-success">
                <div class="card-header">
                    <h5 class="card-title m-2 text-light">
                        Registered Users</h5>
                </div>

                <div class="card-body">

                    <?php
                    if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
                        echo "<div class='alert alert-danger' role='alert'>
                            " . $_SESSION['status'] . "</div>";
                        unset($_SESSION['status']);
                    }

                    if (isset($_SESSION['success']) && $_SESSION['success'] != '') {
                        echo "<div class='alert alert-success' role='alert'>
                            " . $_SESSION['success'] . "</div>";
                        unset($_SESSION['success']);
                    }

                    ?>

                    <div class="table-responsive">

                        <table style="width: 100%;" id="example1" style="align-items: stretch;" class="table table-hover table-bordered">

                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Image</th>
                                    <th style='text-align: center;'>Delete Account</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                $query = "SELECT * FROM user ORDER BY passenger_id DESC";
                                $row = mysqli_query($con, $query);

                                if ($row->num_rows < 1) echo "<div class='alert alert-danger' role='alert'>
                            No Records Yet
                          </div>";
                                $sn = 0;
                                while ($fetch = $row->fetch_assoc()) {
                                    $id = $fetch['passenger_id']; ?><tr>
                                        <td><?php echo ++$sn; ?></td>
                                        <td><?php echo ($fetch['fullname']); ?></td>
                                        <td><?php echo ($fetch['email']); ?></td>
                                        <td><?php echo ($fetch['phone']); ?></td>
                                        <td><img src="<?php echo "../img/" . ($fetch['upload']); ?>" width="80" height="80" style="border-radius: 50px;" /></td>
                                        <td style='text-align: center;'>

                                            <button onclick="return confirm('You are about to erase this user details. Are you sure you want to continue?')" type="submit" name="del_btn" class="btn btn-danger"> <a href="delete.php?deleteid=<?php echo ($fetch['passenger_id']); ?>" class="hover" style="font-weight: 450; color: white">
                                                    <i class="nav-icon fas fa-trash"></i></a>
                                            </button>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>