<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card card-success">
                <div class="card-header d-flex" style="justify-content: space-between;">
                    <h5 class="card-title m-2 text-light">
                        All Routes</h5>
                    <div class="mt-1">
                        <a href="add_new_route.php"><button type="button" class="btn btn-dark btn-sm">
                                Add New Route &#128696;
                            </button></a>
                    </div>
                </div>

                <div class="card-body">

                    <?php

                    if (isset($_POST['del_route'])) {
                        $id = $_POST["del_id"];
                        $query = "DELETE FROM route WHERE route_id = '$id' ";
                        $result = mysqli_query($con, $query);

                        if ($result) {
                            echo "<div class='alert alert-success' role='alert'> Route deleted successfully.</div>";
                        } else {
                            echo "<div class='alert alert-danger' role='alert'> Sorry, you can't delete route at this time.</div>";
                        }
                    }

                    ?>

                    <table id="example1" style="align-items: stretch;" class="table table-hover w-100 table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 6%;">#</th>
                                <th>From</th>
                                <th>To</th>
                                <th style="width:12%;">Delete Route</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $query = "SELECT * FROM route";
                            $row = mysqli_query($con, $query);

                            if ($row->num_rows < 1) echo "<div class='alert alert-danger' role='alert'>
                            No Records Yet
                          </div>";
                            $sn = 0;
                            while ($fetch = $row->fetch_assoc()) {
                                $id = $fetch['route_id']; ?>

                                <tr>
                                    <td><?php echo ++$sn; ?></td>
                                    <td><?php echo $fetch['start']; ?></td>
                                    <td><?php echo $fetch['stop']; ?></td>
                                    <td style='text-align: center;'>
                                        <form method="POST">
                                            <input type="hidden" class="form-control" name="del_id" value="<?php echo $id ?>" required id="">
                                            <button type="submit" name='del_route' onclick="return confirm('Are you sure you want to delete this route?')" class="btn btn-danger">
                                                <i class="nav-icon fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>