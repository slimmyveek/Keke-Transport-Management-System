<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card card-success">
                <div class="card-header d-flex" style="justify-content: space-between;">
                    <h5 class="card-title m-2 text-light">
                        All Registered Tricycles</h5>
                    <div class='mt-1'>
                        <a href="add_new_tricycle.php"><button type="button" class="btn btn-dark btn-sm">
                                Add New Tricycle &#128643;
                            </button></a>
                    </div>
                </div>

                <div class="card-body">

                    <?php
                    if (isset($_POST['del_tricycle'])) {
                        $id = $_POST["del_id"];
                        $query = "DELETE FROM tricycle WHERE tricycle_id = $id ";
                        $result = mysqli_query($con, $query);

                        if ($result) {
                            echo "<div class='alert alert-success' role='alert'> Tricycle details deleted successfully. </div>";
                        } else {
                            echo "<div class='alert alert-danger' role='alert'> Sorry, you can't erase this tricycle details at this time. </div>";
                        }
                    }

                    ?>
                    <table id="example1" style="align-items: stretch;" class="table table-hover w-100 table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tricycle No.</th>
                                <th>Rider's Name</th>
                                <th>Route</th>
                                <th>Max. Capacity</th>
                                <th style="width: 12%;">Edit / Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM tricycle ORDER BY tricycle_id DESC";
                            $row = mysqli_query($con, $query);

                            if ($row->num_rows < 1) echo "<div class='alert alert-danger' role='alert'> No Record Yet. </div>";
                            $sn = 0;
                            while ($fetch = $row->fetch_assoc()) {
                                $id = $fetch['tricycle_id'];
                            ?>

                                <tr>
                                    <td><?php echo ++$sn; ?></td>
                                    <td><?php echo $fetch['plate_no']; ?></td>
                                    <td><?php echo $fetch['rider_name']; ?></td>
                                    <td><?php echo $fullname = $fetch['route']; ?></td>
                                    <td><?php echo $fetch['capacity'] . " seat(s)"; ?></td>
                                    <td>
                                        <form method="POST">
                                            <a href="edit_tricycle.php?edit_id=<?php echo $id; ?>" class="href"><button type="button" class="btn btn-primary">
                                                    <i class="nav-icon fas fa-edit"></i>
                                                </button></a> -

                                            <input type="hidden" class="form-control" name="del_id" value="<?php echo $id ?>" required id="">
                                            <button type="submit" name="del_tricycle" onclick="return confirm('Are you sure you want to erase this tricycle details?')" class="btn btn-danger">
                                                <i class="nav-icon fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>