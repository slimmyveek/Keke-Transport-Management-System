<?php
session_start();
include('includes/connect.php');

 if (isset($_GET["deleteid"])){
     $id = $_GET["deleteid"];
     $query = "DELETE FROM user WHERE passenger_id = '$id' ";
     $result = mysqli_query ($con, $query);
 }
 
 if ($result){
     $_SESSION ['success'] = "The user account has been deleted successfully.";
     header('Location: users.php');
 } 
 else {
     $_SESSION ['status'] = "We encountered a problem trying to delete this user account.";
     header('Location: users.php');
 }
