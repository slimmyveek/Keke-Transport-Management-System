<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
    <h4>Reply Message</h4>
    <i class="fa fa-envelope"></i> : <?php echo $_GET['passenger_id']; ?>
    <?php
    if (isset($_POST['send_reply'])) {
        $passenger_id = $_GET['passenger_id'];
        $reply = $_POST['reply'];
        $query = "UPDATE feedback SET response = '$reply' WHERE passenger_id= '" . $passenger_id . "'";
        $res = mysqli_query($con, $query);
        if ($res === true) {
            // echo ('Reply sent!');
            echo "<div class='alert alert-success' role='alert'> Reply sent succesfully! </div>";
            // header ("Location: feedbacks.php");
        } else {
            // echo ('Reply could not be sent!');
            echo "<div class='alert alert-danger' role='alert'> Reply could not be sent! Please try again! </div>";
            // header ("Location: reply_feedback.php");
        }
    }
    ?>

    <form action="" method="post">
        <p class="mt-2" style="color: #adadad;">Type your reply: <textarea class="form-control" cols="30" rows="5" name="reply" required minlength="3"></textarea>
        </p>
        <hr>
        <input class="btn btn-warning" type="submit" value="Reply" name='send_reply' style="width:30%;">
    </form>
    <a href="feedbacks.php" class=""><button class="btn btn-dark mt-2" style="border-radius:20px; width: 30%;">Back</button></a>

    <?php
    include('includes/scripts.php');
    include('includes/footer.php');
    ?>