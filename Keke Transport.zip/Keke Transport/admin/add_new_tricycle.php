<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
<h4>Add new Tricycle</h4>

<?php
 if (isset($_POST["submit"])){
     $plate_no = $_POST["tricycle"];
     $rider_name = $_POST["rider"];
     $route = $_POST["route_id"];
     $capacity = $_POST["capacity"];
     
     //checking if tricycle details already exist
     $check = $con->query("SELECT * FROM tricycle WHERE plate_no = '$plate_no' ")->num_rows;
        if ($check > 0) {
            echo "<div class='alert alert-danger' role='alert'> This tricycle details already exists. </div>";
        } else if ($check < 1) {
            //proceeding to insert new details
            $query = "INSERT INTO tricycle (plate_no, rider_name, route, capacity, ticket) VALUES ('$plate_no', '$rider_name', '$route', '$capacity', 'NULL')";
     $result = mysqli_query ($con, $query);
        
 if ($result){
    //  header('Location: tricycles_riders.php');
    echo "<div class='alert alert-success' role='alert'> Tricycle details added successfully. </div>";
 } 
 else {
    //  header('Location: add_new_tricycle.php');
     echo "<div class='alert alert-danger' role='alert'> Sorry, this tricycle details can not be added at this time. </div>";
 }
}
}
?>

<form method="post">        
    <p>Tricycle Plate No: <input type="text" class="form-control" name="tricycle" required minlength="8" id=""></p>
  
    <p>Rider's Name: <input type="text" class="form-control" name="rider" required minlength="3" id=""></p>

    <p>Route: <select class="form-control" name="route_id" required id="">
                                <option value="">--Select Route--</option>
                                <?php
                                $query= "SELECT * FROM route";
                                $row = mysqli_query ($con, $query);
                                while ($fetch = $row->fetch_assoc()) {
                                    echo "<option value='" . $fetch['start'] . " to " . $fetch['stop'] . "'>" . $fetch['start'] . ' to ' . $fetch['stop'] . "</option>";
                                }
                                ?>
                            </select>

    <p>Maximum Capacity: <input type="number" min='1' value="5" class="form-control" name="capacity" required id=""></p>
 
    <input class="btn btn-warning" type="submit" value="Add Tricycle" name='submit' style="width: 30%">
    
</form>
    <a href="tricycles_riders.php" class=""><button type="button" class="btn btn-dark mt-2" style="border-radius:20px; width: 30%;">Back</button></a>

</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>