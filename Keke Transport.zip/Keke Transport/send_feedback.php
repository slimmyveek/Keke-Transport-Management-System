<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="" style="padding: 50px">
    <h4 class="">Send New Feedback </h4>
    <?php

    if (isset($_POST['sendFeedback'])) {
        $passenger_id = $_SESSION['fullname'];
        $msg = $_POST['message'];
        // $send = sendFeedback($msg);
        // echo $send;
        $query = "INSERT INTO feedback (passenger_id, message) VALUES ('$passenger_id', '$msg')";
        $res = mysqli_query($con, $query);
        if ($res === true) {
            // echo ('Feedback sent!');
            echo "<div class='alert alert-success' role='alert'> Feedback sent! We will get back to you as soon as possible. </div>";
            // header ("Location: feedback.php");
        } else {
            // echo ('Feedback could not be sent!');
            echo "<div class='alert alert-danger' role='alert'> Feedback could not be sent! Please try again! </div>";
            header("Location: send_feedback.php");
        }
    }

    ?>
    <form action="" method="post">
        <p style="color: #adadad;">
            Type Message: <textarea name="message" required minlength="10" cols="30" rows="5" class="form-control"></textarea>
        </p>
        <hr>
        <input type="submit" name="sendFeedback" class="btn btn-warning" value="Send" style="width:30%;">
    </form>
    <a href="feedback.php" class=""><button class="btn btn-dark mt-2" style="border-radius:20px; width: 30%;">Back</button></a>

    <?php
    include('includes/scripts.php');
    include('includes/footer.php');
    ?>