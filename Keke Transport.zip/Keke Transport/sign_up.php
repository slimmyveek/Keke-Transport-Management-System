<?php

include('includes/connect.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./bootstrap-5.2.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>

<body>
    <!--Navigation-->
    <nav class="navbar navbar-expand-md bg-dark navbar-dark py-3 fixed-top">
        <div class="container">
            <img src="img/steering.png" alt="" style = "width: 2.3%; margin-right: 10px;"><a href="index.php" class="navbar-brand">Keke Transport Management System</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
                <span class="navbar toggler icon"></span>
            </button>

            <div class="collapse navbar-collapse" id=navmenu>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link page-scroll">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="index.php" class="nav-link page-scroll">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a href="map/Afikpo North - Google Maps.pdf" target="blank" class="nav-link">Map</a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_login.php" class="nav-link">Admin</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!--Sign Up form and Showcase-->
    <section class="text-center">
        <div class="container">
            <div>
                <img class="w-25" src="./img/Create Profile.svg" alt="">
            </div>

            <h3>Registration</h3>

            <div class="registration">

            <?php

    if (isset($_POST["submit"])){
    $fullname=$_POST["fullname"];
    $phone=$_POST["phone"];
    $email=$_POST["email"];
    $upload=$_POST["upload"];
    $gender=$_POST["gender"];
    $password=$_POST["password"];
    $cpassword=$_POST["cpassword"];

    //checking if passenger details already exists
     $check = $con->query("SELECT * FROM user WHERE email = '$email' ")->num_rows;
        if ($check > 0) {
            echo "<div class='alert alert-danger' role='alert'> Oops! Your details already exists. You can proceed to log in. </div>";
        }
        //proceeding to insert new details after checking that passwords match
        elseif ($password === $cpassword) {
            $query= "INSERT INTO user (fullname, phone, email, upload, gender, password, cpassword) VALUES ('$fullname', '$phone', '$email', '$upload', '$gender', '$password', '$cpassword')";
            $result = mysqli_query ($con, $query);
        if ($result===true){
            // $_SESSION['success'] = "Congratulations! Your details have been registered successfully .";
            echo "<div class='alert alert-success' role='alert'> Congratulations! Your details have been registered successfully. </div>";
            header ('passenger_login.php');
        } else{
            //die(mysqli_error($con));
            // $_SESSION['status'] = "Sorry. We are unable to complete your registration at this time!";
            echo "<div class='alert alert-danger' role='alert'> Sorry. We are unable to complete your registration at this time! </div>";
            header ('sign_up.php');
        }
    } elseif ($password != $cpassword){
        //echo "Passwords do not match!";
        echo "<div class='alert alert-danger' role='alert'> The passwords you have provided do not match. Kindly check and try again. </div>";
        header ('sign_up.php');
    }
    }
?>

                <form method="POST">
                    <div class="row">
                        <div class="txt_field">
                            <input type="text" required name="fullname">
                            <label>Full Name</label>
                        </div>
                    </div>

                    <div class="row pb-5">
                        <div class="txt_field col-lg-5">
                            <input type="number" required name="phone">
                            <label>Phone</label>
                        </div>

                        <div class="col-lg-2">

                        </div>
                        <div class="txt_field col-lg-5">
                            <input type="text" required name="email">
                            <label>Email</label>
                        </div>
                    </div>

                    <div class="row text-start">
                        <div class="col-lg-6">
                            Upload Image: <input type="file" name="upload">
                        </div>

                        <div class="col-lg-1"></div>

                        <div class="col-lg-5">
                            Gender: <input type="radio" name="gender" value="Male">
                            <label>Male</label>
                            <input type="radio" name="gender" value="Female">
                            <label>Female</label>
                        </div>
                    </div>

                    <div class="row">
                        <div class="txt_field col-lg-5">
                            <input type="password" required name="password">
                            <label>Password</label>
                        </div>
                        <div class="col-lg-2"></div>
                        <div class="txt_field col-lg-5">
                            <input type="password" required name="cpassword">
                            <label>Confirm Password</label>
                        </div>
                    </div>


                    <input type="submit" value="Sign Up" id="register" name="submit">
                    <div class="signup">
                        Already have an account? <a href="passenger_login.php">Login</a>
                    </div>
                </form>
            </div>
        </div>
    </section>


    <!--Footer-->
    <footer class="text-center">
        <div class="container">
            <div class="row p-3">
                <div class="col-md-4">
                    <p class="footer-links"><a href="#">Terms of Use</a> <a href="#">Privacy Policy</a></p>
                </div>
                <div class="col-md-4"> <small> Copyright &copy; 2023 All Rights Reserved. </small></div>
                <div class="col-md-4">
                </div>
            </div>
        </div>
    </footer>


    <script src="./bootstrap-5.2.2-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>