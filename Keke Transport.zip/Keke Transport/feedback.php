<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="container-fluid">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h3>Feedback</h3>
        </div>

    </div>
</div>


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class='alert alert-primary' role='alert'>
                <h5><i class="fas fa-info"></i> Info:</h5>
                We always want to hear from you!
                You will be replied within 24-hours.
            </div>



            <div class="card">
                <div class="card-header d-flex" style="justify-content: space-between;">
                    <h5 class="card-title m-2 text-light">All Feedbacks</h5>
                    <div class='m-1'>
                        <a href="send_feedback.php" class="href"><button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#add">
                                Send New Feedback
                            </button></a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" id='example1'>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Your Comment</th>
                                <th>Response</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sn = 0;
                            $query = "SELECT * FROM feedback WHERE passenger_id = '" . $_SESSION['fullname'] . "'";
                            $result = mysqli_query($con, $query);
                            if ($result->num_rows < 1) echo "<div class='alert alert-primary' role='alert'><marquee> You have not sent out any feedback yet. Send us a feedback on how we can serve you better.</marquee> </div>";
                            while ($row = $result->fetch_assoc()) {
                                $sn++;
                                echo "<tr>
                                    <td>$sn</td>
                                    <td>" . $row['message'] . "<br>
                                        <em><small class='text-secondary'>~ Sent: " . $row['date'] . "</small></em>
                                        </td>
                                    <td class='text-primary'>" . ($row['response'] == NULL ? '<span class="text-danger">-- No Response Yet --</span>' : $row['response']) . "</td>
                                    </tr>";
                            }
                            ?>
                        </tbody>
                    </table>


                </div>

                <br />
            </div>
        </div>
    </div>


    <?php
    include('includes/scripts.php');
    include('includes/footer.php');
    ?>