<?php
include('includes/connect.php');
include('includes/header.php');
include('includes/sidebar.php');
?>

<div class="container-fluid">

    <div class="card card-warning">
        <div class="card-header">
            <h5 class="card-title m-2 text-light">Book a Tricycle Ride</h5>
        </div>
        <div class="card-body">
            <?php
            if (isset($_POST["submit"])) {
                $passenger_id = $_SESSION['fullname'];
                $route = $_POST['route'];
                $plate_no = $_POST['plate_no'];
                $seat = $_POST['seat_no'];
                $date = $_POST['date'];
                $time = $_POST['time'];

                $sql = "INSERT INTO booked (route, plate_no, passenger_id, seat, date, time) VALUES ('$route', '$plate_no', '$passenger_id', '$seat', '$date', '$time')";
                $res = mysqli_query($con, $sql);

                if ($res === true) {
                    echo "<div class='alert alert-success' role='alert'> You have successfully booked a ride. Enjoy your trip! </div>";
                } else {
                    echo "<div class='alert alert-danger' role='alert'> Sorry, you can't book this trip at this time. Try again later.</div>";
                }
            }
            ?>

            <?php
            if (isset($_POST["cancel"])) {
                $passenger_id = $_SESSION['fullname'];
                $route = $_POST['route'];
                // $plate_no = $_POST['plate_no'];
                // $seat= $_POST['seat_no'];
                $date = $_POST['date'];
                $time = $_POST['time'];

                $s = "DELETE FROM booked WHERE route = '" . $route . "' AND date = '" . $date . "' AND passenger_id = '" . $passenger_id . "' ";
                $r = mysqli_query($con, $s);

                if ($r === true) {
                    echo "<div class='alert alert-success' role='alert'> You have successfully cancelled your booked ride. </div>";
                } else {
                    echo "<div class='alert alert-danger' role='alert'> Sorry, you can't cancel this trip at this time. </div>";
                }
            }
            ?>

            <table id="example1" style="align-items: stretch;" class="table table-hover w-100 table-bordered table-striped<?php //
                                                                                                                            ?>">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Route</th>
                        <th>Tricycle No.</th>
                        <th>Available Seat(s)</th>
                        <th>Date/Time of Departure</th>
                        <th style='text-align: center; width: 16%;'>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM schedule WHERE ticket_status = 1 AND date = '" . date("d-m-Y") . "' ORDER BY date ASC, time ASC";
                    $result = mysqli_query($con, $query);
                    if ($result->num_rows < 1) echo "<div class='alert alert-danger' role='alert'>
                            Sorry, there are no schedules at the moment! Please visit after some time.
                          </div>";
                    $sn = 0;
                    while ($fetch = mysqli_fetch_array($result)) {
                        //Check if the current date is same with Database scheduled date
                        $curr_date = strtotime(date("d-m-Y"));
                        $db_date = strtotime($fetch['date']);
                        if ($db_date == $curr_date) {
                            //Oh yes, so what should happen?
                            //Check for the time. If there is still about an hour left, proceed else, skip this data
                            $db_time = strtotime($fetch['time']);
                            $curr_time = strtotime(date('H:i'));
                            if ($curr_time >= $db_time) {
                                continue;
                            }
                        }

                        $id = $fetch['schedule_id']; ?>

                        <form method="post">
                            <tr>
                                <td><?php echo ++$sn; ?>
                                    <input type="hidden" class="form-control" name="passenger_id" value="<?php echo $_SESSION['fullname']; ?>" required id="">
                                </td>
                                <td><?php
                                    $cond = $con->query("SELECT * FROM route WHERE route_id = '" . $fetch['route_id'] . "'");
                                    while ($r = $cond->fetch_assoc()) {
                                        echo ($r['start']) . " to " . ($r['stop']);
                                    ?>
                                        <input type="hidden" class="form-control" name="route" value="<?php echo $fetch['route_id']; ?>" required id="">
                                    <?php
                                    }
                                    ?>
                                </td>
                                <td><?php
                                    $cond = $con->query("SELECT * FROM tricycle WHERE tricycle_id = '" . $fetch['tricycle_id'] . "'");
                                    while ($r = $cond->fetch_assoc()) {
                                        echo ($r['plate_no']);

                                    ?>
                                        <input type="hidden" class="form-control" name="plate_no" value="<?php echo ($r['plate_no']); ?>" required id="">
                                    <?php
                                    }
                                    ?>
                                </td>
                                <td>
                                    <!-- Calculating the number of available seats left after booking -->
                                    <?php echo ($fetch['seat']) - ($row =  $con->query("SELECT * FROM booked WHERE route = '" . $fetch['route_id'] . "' AND date = '" . $fetch['date'] . "' ")->num_rows) . " seat(s) available"; ?>
                                    <input type="hidden" class="form-control" name="seat_no" value="<?php echo ($fetch['seat']) - ($row =  $con->query("SELECT * FROM booked WHERE route = '" . $fetch['route_id'] . "' AND date = '" . $fetch['date'] . "' ")->num_rows); ?>" required id="">
                                </td>

                                <td><?php echo $fetch['date'], " / ", $fetch['time']; ?>
                                    <input type="hidden" class="form-control" name="date" value="<?php echo $fetch['date']; ?>" required id="">
                                    <input type="hidden" class="form-control" name="time" value="<?php echo $fetch['time']; ?>" required id="">
                                </td>

                                <td style='text-align: center;'>
                                    <?php
                                    //Check if there's still an available seat 
                                    $available = ($fetch['seat']) - ($row =  $con->query("SELECT * FROM booked WHERE route = '" . $fetch['route_id'] . "' AND date = '" . $fetch['date'] . "' ")->num_rows);
                                    //If the number of available seats gets to zero, remove the schedule and make it unavailable for further booking        
                                    if ($available < 1) {
                                    ?>
                                        <button disabled="disabled" class="btn btn-secondary">Fully Booked</button>
                                        <?php } else {
                                        //checking if passenger has already booked
                                        $check = $con->query("SELECT * FROM booked WHERE route = '" . $fetch['route_id'] . "' AND date = '" . $fetch['date'] . "'  AND passenger_id = '" . $_SESSION['fullname'] . "' ")->num_rows;
                                        if ($check > 0) {
                                        ?>
                                            <!-- <button disabled="disabled">Booked</button> -->
                                            <button type="cancel" name="cancel" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel Booking</button>
                                        <?php } else { ?>
                                            <button type="submit" name="submit" class="btn btn-primary" onclick="return confirm('Your fare for this trip is 300 Naira. Kindly proceed to make payments to reserve a seat on this tricycle.')">Book</button>
                                        <?php } ?>
                                    <?php } ?>
                                </td>
                            </tr>
                        </form>

                    <?php
                    }
                    ?>

                </tbody>

            </table>
        </div>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>